
 class Data{
    constructor(students,courses){
        this.students=students;
        this.courses=courses;
    }
}


var dataCollection=null;



 exports.initialize= function (){
    return new Promise((resolve, reject) => {
    const fs=require('fs')
   var StudentPath  =   "/Users/chahatjain/Desktop/Assignment2(Web)/data/students.json"
   var CoursePath   =   "/Users/chahatjain/Desktop/Assignment2(Web)/data/courses.json"
    //reading Student.json file from data folder
    var StudentDataFromFile = () => JSON.parse(fs.readFileSync(StudentPath, "UTF8"));
    
    //reading courses.json file from data folder
    var CourseDataFromFIle = () => JSON.parse(fs.readFileSync(CoursePath, "UTF8"));
    
    //Passing the data of student and courses to data Collection
    dataCollection=new Data(StudentDataFromFile(),CourseDataFromFIle())
    resolve;
})
    
}


 exports.getAllStudents = function(){
    return new Promise((resolve, reject) => {

    if (dataCollection.length === 0) 
        reject("no results returned");
    
    else
        resolve(dataCollection.students)
    
})
}

exports.getCourses = function (){
    return new Promise((resolve, reject) => {
        
    if (dataCollection.length === 0) 
        reject("no results returned");
    
    else
        resolve(dataCollection.courses)
    
})
}

 exports.getTAs = function(){
    return new Promise((resolve, reject) => {
        
        if (dataCollection.length != 0) {
            var obj=[];
            for (let i = 0; i < dataCollection.students.length; i++) {
                if(dataCollection.students[i]["TA"] != false)
                    obj.push(dataCollection.students[i])
                
              }
              resolve(obj)

        } 
        else 
        reject(new Error("Error While Fetching Data!!!"));
        
})
}






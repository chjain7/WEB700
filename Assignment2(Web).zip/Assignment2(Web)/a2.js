const cd = require('./modules/collegeData.js');
/*********************************************************************************
*  WEB700 – Assignment 2
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.  
*  No part of this assignment has been copied manually or electronically from any other source
*  (including web sites) or distributed to other students.
* 
*  Name: Chahat Jain Student ID: 177139219 Date: Jan 25 2023
********************************************************************************/ 
 
try {

    cd.initialize()
    cd.getAllStudents().then(StudentDataFromFile => {
        console.log("successfully retrieved "+ Object.keys(StudentDataFromFile).length+" students");
      });
    cd.getCourses().then(CourseDataFromFile => {
        console.log("successfully retrieved "+ Object.keys(CourseDataFromFile).length+" courses");
      });

    
    cd.getTAs().then(taData => {
        console.log("successfully retrieved "+ Object.keys(taData).length+" TAs");
      });
} 

catch(err) {

    console.log(err+" Cannot fetch Data");

}
